 __   __        __   ___          __   __  
(__` |__)  /\  |  \ |__      /\  |__) |__) 
.__) |    /--\ |__/ |___    /--\ |    |    
                                                                  
---The Problem---
People’s properties inevitably need maintenance. 
This includes cleaning, gardening, mowing the lawn, car washing, window washing, pressure washing, etc. 
The housing value of a neighborhood is impacted by the state of each house in the neighborhood, which is why it's important to keep your home looking nice. 
However this raises a problem. Many people may not have the ability to care for and maintain a clean property for reasons including physical health, financial status, laziness etc.

---Sign Up---
To use this app, the first thing you will need is an account. 
Simply create an account upon launching the app for the first time by creating a username and password and click the submit button for your account to be created. 
Afterwards the program will prompt you to restart the app, and will greet you with the login screen. 

---Location---
Once signed in, the process of saving your location will begin. 
A map of Ontario will be shown as well as a list of regions. 
You will be asked to enter your region (A number from 1-4, corresponding to the regions in the map shown. 
After pressing the continue button the next screen shown will show a closeup map of the region you've chosen, and will list the towns available within that region (similar to the previous screen). 
Choose your town (Enter the number corresponding to the town in the list), and press continue. Your location has now been saved for next time, and a message box will appear notifying you of this. 

---Staff---
On the next screen, a list of 5 freelance laborers will appear, along with their job, location, rating, and hourly rate. 
You may select a worker to see more information about them, and you may choose to hire them. Upon hiring a worker, you should be notified that the worker is on their way.

---Review---
If a laborer has been hired in a previous session, the next time the SPADE app launches a screen will appear that will ask the user to review their chosen laborer and is completely optional.
