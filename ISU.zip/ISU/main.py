#Matteo De Angelis Geraldo and Ryan Coones
#2022/11/25 - 2022/12/16
#SPADE APP
import googlemaps
import tkinter
from tkinter import messagebox
import random

#SPLASH SCREEN
#this block of code centers the splash box on the computers screen
splashScreen = tkinter.Tk() # creates a splash screen
splashWidth = 600 #width of splash
splashHeight = 338 #length of splash
screenWidth = splashScreen.winfo_screenwidth()  # Width of the screen
screenHeight = splashScreen.winfo_screenheight() # Height of the screen
x = (screenWidth/2) - (splashWidth/2)
y = (screenHeight/2) - (splashHeight/2)
splashScreen.geometry('%dx%d+%d+%d' % (splashWidth, splashHeight, x, y))

splashScreen.iconbitmap("icon.ico") #icon
splashScreen.title("WELCOME") #title
splashScreen.overrideredirect(True) #remove border
splashScreen.configure(bg="green") #make the background Green

# The splash screen Text
splashText = tkinter.Label(splashScreen, text="SPADE", font=("Verdana", 70, "bold"), fg="white", bg="green")
smallSplashText = tkinter.Label(splashScreen, text="redirecting...", font=("Verdana", 20,), fg="white", bg="green")
splashText.place(x = splashWidth/2, y = splashHeight/3, anchor="center")
smallSplashText.place(x = splashWidth/2, y = splashHeight/2+70, anchor="center")

#dictionary of the towns of ontario, keys being the region
gtaRegions = {
    "1. York Region" :["Georgina", "East gwillimbury", "Newmarket", "Aurora", "Gormley", "King City", "Whitchurch stouffville", "Richmond hill", "Vaughan", "Markham",  "Toronto"],
    "2. Durham Region":[ "Pickering", "Ajax",  "Whitby", "Oshawa", "Clarington", "Port Perry", "Uxbridge"],
    "3. Halton Region":["Halton-hills", "Milton", "Oakville", "Burlington"],
    "4. Peel Region":["Caledon", "Bolton", "Brampton", "Mississauga"]}
    #https://files.ontario.ca/mhstci-tourism-region-maps-3/mhstci-southern-ontario-map-regions-en-fr-2022-06-24.pdf
    #link to map if we ever want to expand (NEVER!!!!)

#list of staff names for later
nameList = [
    "Domingo", "James", "Leonardo", "Alfredo", "Jack", "Salvador", "Samuel", "Joseph", "William", "Thomas", 
    "Julio", "Ethan", "Benjamin", "Lewis", "Matthew", "Alexander", "Adam", "Owen", "Aaron", "Archie", 
    "Edward", "Connor", "Liam", "Jake", "Michael", "Tyler", "Nathan", "Peter", "Jojo", "Miguel",
    "Tate", "Angela", "Kathleen", "Lila", "Sharon", "Isabella", "Jose", "Alexia", "Jace", "Vaughan", 
    "Julia", "Rihanna", "Ronaldo", "Laura", "Grace"
          ]

#last names for the staff later
LastInitialList = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']                                   

#list of a bunch of worker descriptions
jobDict = {
    "Landscaper":"I'm good at lawnmowing and general \nlandscaping.", 
    "House cleaning":"I'm good at house cleaning aswell as\nmess/stain cleanup.", 
    "Roofer":"I'm good at roofs. Shingles, gutters, you name it.", 
    "Organic matter disposal":"If you have a lot of leaves or plant waste, I can \nrake them all up and dispose of them for you.",
    "Snow Removal":"I can take care of your snow removal needs, \nso you can spend the day warm and cozy \ninside while I take care of the cold outside",
    "Apartment care":"Need your apartment cleaned quick? I can \nmake your apartment sparkle in no time!",
    "Pool care":"Ill tend to your pool, and get it all cleaned up! \nI can also find and patch leaks in your liner!",
    "Driveway care":"Is your driveway looking a little bit old and \nbeaten up? Maybe its time for a refresh! \nIll come and re-tar your driveway in a jiffy!",
    "Gardener":"Are your plants looking a little withered? \nI can fix them up in no time and \nmake them look pretty again!", 
    "Painter":"Would you like to try a new wall colour? \nAre your walls in need of some resurfacing? \nIm the one for the job!", 
    "Window cleaner":"Are your windows looking a filthy? \nIll get em sparkly clean and like \nnew without you lifting your finger!"
        }

def locationAsk(): # Process to ask and save the users location in the location file - made by matteo and ryan
    #stop splash and start sign in
    signIn.destroy()
    global locationAsk
    locationAsk = tkinter.Tk() # Create main window
    appWidth = 540 # Set the window width
    appHeight = 960 # Set the window height
    compWidth = locationAsk.winfo_screenwidth()  # Width of the screen
    compHeight = locationAsk.winfo_screenheight() # Height of the screen
    x = (compWidth/2) - (appWidth/2) # Spawn the window in the middle of the screen
    y = (compHeight/2) - (appHeight/2)
    locationAsk.geometry('%dx%d+%d+%d' % (appWidth, appHeight, x, y))# determines the size of the window

    locationAsk.iconbitmap("icon.ico") # Replaces the default icon at the top of the window
    locationAsk.title("SPADE") #Sets the title of the window
    locationAsk.configure(bg="green") # sets the background colour of the window
    locationAsk.resizable(False,False) #Makes the window unable to be resized
    
    global logo #makes variable global so it can be used outside of the function
    logo = tkinter.PhotoImage(file="logo.png") # makes a variable containing the logo image file
    spadeLogo = tkinter.Label(locationAsk, image=logo, border=0, bg="green") # creates a packable object 
    spadeLogo.pack(ipady=20) # Inserts the logo at the top of the window
    
    def userRegion(): # Asks the user what region they belong to - made by matteo and ryan
        def regionSave(): # Gets the users region input and takes the town input - made by matteo and ryan
            #----------------------CONVERTING TOWN INPUT TO VARIABLE----------------------
            def townSave(): # Saves the users town and region in the location file - made by matteo and ryan
                with open("location.txt", "r+") as townLocationFile:
                    try:
                        userTownNumber = int(townInput.get())
                        if int(userTownNumber) > int(len(gtaRegions[userRegion])) or int(userTownNumber) <= 0:
                            messagebox.showinfo("Not In List", "Please select a region listed below.")
                        else:
                            usersTown = gtaRegions[userRegion][userTownNumber-1]
                            townLocationFile.write(f"{userRegion}\n{usersTown}")
                            messagebox.showinfo("Location Saved", "Your location has been saved for next time!")
                            signIn.after(200, mainApp)
                            
                    except:
                        messagebox.showinfo("Not a Number", "Please input a number.")
            # ----------------------------------Saving the region to location.txt----------------------------------
            with open("location.txt", "r+") as locationFile: # opens the location file
                try:
                    userRegionNumber = int(regionInput.get()) # takes the region input
                    if userRegionNumber > 4 or userRegionNumber <= 0: # if the region input is not a number from 1-4
                            messagebox.showinfo("Not In List", "Please select a region listed below.") # tell the user to repick a region
                    else: # if the input is acceptable, destroy everything on the screen
                        for widget in locationAsk.winfo_children():
                            widget.destroy()
                        
                        global logo # logo for top of screen
                        logo = tkinter.PhotoImage(file="logo.png")
                        spadeLogo = tkinter.Label(locationAsk, image=logo, border=0, bg="green")
                        spadeLogo.pack(ipady=20)                    
                        
                        # ask the user which town they belong to inside the region
                        enterTownText = tkinter.Label(locationAsk, text="Which of the following Towns do you belong to?", font=("Microsoft Yahei", 16), fg="white", bg="green")
                        enterTownText.pack(ipady=20)

                        # Find the users town based on the number they inputted
                        for i in gtaRegions:
                            if int(i[0]) == int(userRegionNumber):
                                userRegion = i # to be used later

                        #displays the correct map according to their region
                        global townsImg
                        if userRegion == "1. York Region":
                            townsImg = tkinter.PhotoImage(file="Maps/York.png")
                        elif userRegion == "2. Durham Region":
                            townsImg = tkinter.PhotoImage(file="Maps/Durham.png")
                        elif userRegion == "3. Halton Region":
                            townsImg = tkinter.PhotoImage(file="Maps/Halton.png")
                        elif userRegion == "4. Peel Region":
                            townsImg = tkinter.PhotoImage(file="Maps/Peel.png")
                        tkinter.Label(locationAsk, image=townsImg, border=5, bg="black").pack()

                        # Print the towns in the users region
                        count = 0
                        for town in gtaRegions[userRegion]:
                            count += 1
                            townText = tkinter.Label(locationAsk, text=(f"{count}. {town}"), font=("Microsoft Yahei", 10), fg="white", bg="green")
                            townText.pack()

                        #------REGION INPUT-------
                        # A textbox for the user to enter their town
                        townInput = tkinter.Entry(locationAsk, width=32, fg="black", border=2, bg="white", font=("Microsoft Yahei", 16), cursor="hand2")
                        townInput.pack()
                        townInput.insert(0, "(Ex. 1)")
                        #------BUTTON-------
                        # Submit button to continue to the next screen
                        saveTownButton = tkinter.Button(locationAsk, width=16, text="Continue", border=0, font=("Microsoft Yahei Light", 16), command=townSave, cursor="hand2")
                        saveTownButton.pack()
                except:
                    messagebox.showinfo("Not a Number", "Please input a number.") # If the user doesnt enter a number make a message box telling the user to input a number
        
        #----------------------SCREEN THAT ASKS USER FOR REGION#----------------------
        global regionsImg # regions map
        regionsImg = tkinter.PhotoImage(file="Maps/Region.png")
        tkinter.Label(locationAsk, image=regionsImg, border=5, bg="black").pack()
        
        # Asks the user what region they belong to
        enterRegionText = tkinter.Label(locationAsk, text="Which of the following regions do you belong to?", font=("Microsoft Yahei", 16), fg="white", bg="green")
        enterRegionText.pack(ipady=20)
        
        # Put the supported regions under the map
        for region in gtaRegions:
            regionText = tkinter.Label(locationAsk, text=region, font=("Microsoft Yahei", 18), fg="white", bg="green")
            regionText.pack()
        Enterspace = tkinter.Label(locationAsk, text=" ", font=("Microsoft Yahei", 18), fg="white", bg="green")
        Enterspace.pack(ipady=10)
        #------REGION INPUT-------
        # A text box for the user to put their region in
        regionInput = tkinter.Entry(locationAsk, width=32, fg="black", border=2, bg="white", font=("Microsoft Yahei", 16))
        regionInput.pack()
        regionInput.insert(0, "(Ex. 1)")
        Enterspace2 = tkinter.Label(locationAsk, text=" ", font=("Microsoft Yahei", 18), fg="white", bg="green")
        Enterspace2.pack(ipady=10)
        #------BUTTON-------
        # Submit button for the user to continue after entering their region
        saveLocButton = tkinter.Button(locationAsk, width=16, text="Continue", border=0, font=("Microsoft Yahei Light", 16), command=regionSave, cursor="hand2")
        saveLocButton.pack()
    # upon signing in, read the file
    with open("location.txt", "r+") as locationFile:
        if locationFile.read() == "": # If the file is empty, go through location saving process
            userRegion()
        else: # If the user has previously saved the location go straight to the main app
            mainApp()

# Create an empty list to be filled so the staff can be assigned locations
staffLocList = []
def createDude(nameList, LastInitialList, jobDict, staffLocList): # function that creates a staff worker - made by matteo and ryan
    with open("location.txt", "r+") as staffLocationFile:
        locFileLines = staffLocationFile.read().splitlines()
        for towns in gtaRegions[locFileLines[0]]:
            staffLocList.append(towns)
    
    staffName = random.choice(nameList) #chooses a random name from the list
    staffLastInitial = random.choice(LastInitialList) #gives the staff a random last name
    staffLastInitial = staffLastInitial.upper() #make upercase
    staffPay = (f"${random.randint(15, 20)}/hr") # gives the staff a random ammount of hourly pay between $15 - $20
    staffLocation = random.choice(staffLocList)  #gives the staff a random location in the region
    staffStars = (random.randint(7,10))/2       #gives the staff a random star count around 3 - 5 start (our app is to good for poor reviews)           
    jobs, staffDescriptions = random.choice(list(jobDict.items())) #gives the staff a random job description
    return staffName, staffLastInitial, staffPay, staffLocation, staffStars, staffDescriptions # returns all the random values we just generated

def review(): #makes window and asks user to review last purchase - made by matteo and ryan
    spadeApp.destroy()#kill main
    
    def postReview(): #function runs when button is clicked - made by matteo and ryan
        messagebox.showinfo("Review Posted!", "Thank you for contributing to the app!")#prints this then ends itself
        review.after(100,review.destroy())  
        mainApp()  
    review = tkinter.Tk()
    appWidth = 540 # Set the window width
    appHeight = 960 # Set the window height
    compWidth = review.winfo_screenwidth()  # Width of the screen
    compHeight = review.winfo_screenheight() # Height of the screen
    x = (compWidth/2) - (appWidth/2) # Spawn the window in the middle of the screen
    y = (compHeight/2) - (appHeight/2)
    review.geometry('%dx%d+%d+%d' % (appWidth, appHeight, x, y))# determines the size of the window
    review.iconbitmap('icon.ico')
    review.title('Review')
    review.configure(bg='white')
    review.resizable(False,False) #Makes the window unable to be resized   

    global logo #makes variable global so it can be used outside of the function
    logo = tkinter.PhotoImage(file="logo.png") # makes a variable containing the logo image file
    spadeLogo = tkinter.Label(review, image=logo, border=0, bg="green") # creates a packable object 
    spadeLogo.pack(ipady=20, fill=tkinter.X) # Inserts the logo at the top of the window
    tkinter.Label(bg="black").pack(fill=tkinter.X)

    # ask user if they are satisfied with the service
    # reads staff.txt, and tells the user to leave a review for the worker
    with open("staff.txt", "r+") as staffFileTxt:
        staffread = (staffFileTxt.readline())
        if staffread == "":
            tkinter.Label(review, text=("How did we do?"), font=("Microsoft Yahei Bold", 46), fg="black", bg="white").pack()
            tkinter.Label(review, text=(f"Leave a review \nto improve our app!"), font=("Microsoft Yahei Bold", 22), fg="black", bg="white").pack()

            tkinter.Label(bg="white").pack(fill=tkinter.X) #spacer   
            staffFrame = tkinter.Frame(review, width=540, bg="white")  # a container that will hold the staffs printed info
            staffFrame.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
            tkinter.Label(staffFrame, text="Functional", font=("Microsoft Yahei Bold", 20), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
            tkinter.Entry(staffFrame, width=10, fg="black", border=2, bg="white", font=("Microsoft Yahei", 20), cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)

            staffFrame2 = tkinter.Frame(review, width=540, bg="white")  # a container that will hold the staffs printed info
            staffFrame2.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
            tkinter.Label(staffFrame2, text="Ease of Use", font=("Microsoft Yahei Bold", 20), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
            tkinter.Entry(staffFrame2, width=10, fg="black", border=2, bg="white", font=("Microsoft Yahei", 20), cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)

            staffFrame3 = tkinter.Frame(review, width=540, bg="white")  # a container that will hold the staffs printed info
            staffFrame3.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
            tkinter.Label(staffFrame3, text="Stability", font=("Microsoft Yahei Bold", 20), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
            tkinter.Entry(staffFrame3, width=10, fg="black", border=2, bg="white", font=("Microsoft Yahei", 20), cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)

            staffFrame4 = tkinter.Frame(review, width=540, bg="white")  # a container that will hold the staffs printed info
            staffFrame4.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
            tkinter.Label(staffFrame4, text="Other", font=("Microsoft Yahei Bold", 20), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
            tkinter.Entry(staffFrame4, width=10, fg="black", border=2, bg="white", font=("Microsoft Yahei", 20), cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)

            tkinter.Button(review, text ="POST",border = 1,font=("Microsoft Yahei Light", 20),fg="black", bg="green", cursor="hand2", command=postReview).pack() 
            tkinter.Label(bg="white").pack(fill=tkinter.X, expand=4) #spacer
        else:
            tkinter.Label(review, text=("How did I do?"), font=("Microsoft Yahei Bold", 50), fg="black", bg="white").pack()
            tkinter.Label(review, text=(f"Leave a review for {staffread} \nto improve our app!"), font=("Microsoft Yahei Bold", 22), fg="black", bg="white").pack()

            tkinter.Label(bg="white").pack(fill=tkinter.X) #spacer   
            staffFrame = tkinter.Frame(review, width=540, bg="white")  # a container that will hold the staffs printed info
            staffFrame.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
            tkinter.Label(staffFrame, text="On Time", font=("Microsoft Yahei Bold", 30), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
            tkinter.Entry(staffFrame, width=10, fg="black", border=2, bg="white", font=("Microsoft Yahei", 30), cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)

            staffFrame2 = tkinter.Frame(review, width=540, bg="white")  # a container that will hold the staffs printed info
            staffFrame2.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
            tkinter.Label(staffFrame2, text="Quality", font=("Microsoft Yahei Bold", 30), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
            tkinter.Entry(staffFrame2, width=10, fg="black", border=2, bg="white", font=("Microsoft Yahei", 30), cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)

            staffFrame3 = tkinter.Frame(review, width=540, bg="white")  # a container that will hold the staffs printed info
            staffFrame3.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
            tkinter.Label(staffFrame3, text="Friendly", font=("Microsoft Yahei Bold", 30), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
            tkinter.Entry(staffFrame3, width=10, fg="black", border=2, bg="white", font=("Microsoft Yahei", 30), cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)

            staffFrame4 = tkinter.Frame(review, width=540, bg="white")  # a container that will hold the staffs printed info
            staffFrame4.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
            tkinter.Label(staffFrame4, text="Value", font=("Microsoft Yahei Bold", 30), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
            tkinter.Entry(staffFrame4, width=10, fg="black", border=2, bg="white", font=("Microsoft Yahei", 30), cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)

            tkinter.Button(review, text ="POST",border = 1,font=("Microsoft Yahei Light", 30),fg="black", bg="green", cursor="hand2", command=postReview).pack() 
            tkinter.Label(bg="white").pack(fill=tkinter.X, expand=4) #spacer

            
def mainApp(): # Displays staff and map - Made by matteo and ryan
    #stop splash and start sign in
    locationAsk.destroy() # delete the locationask window
    global spadeApp
    spadeApp = tkinter.Tk()
    appWidth = 540 # Set the window width
    appHeight = 960 # Set the window height
    compWidth = spadeApp.winfo_screenwidth()  # Width of the screen
    compHeight = spadeApp.winfo_screenheight() # Height of the screen
    x = (compWidth/2) - (appWidth/2) # Spawn the window in the middle of the screen
    y = (compHeight/2) - (appHeight/2)
    spadeApp.geometry('%dx%d+%d+%d' % (appWidth, appHeight, x, y))# determines the size of the window
    
    spadeApp.iconbitmap("icon.ico") # Replaces the default icon at the top of the window
    spadeApp.title("SPADE") #Sets the title of the window
    spadeApp.configure(bg="white") # sets the background colour of the window
    spadeApp.resizable(False,False) #Makes the window unable to be resized
    
    global logo #makes variable global so it can be used outside of the function
    logo = tkinter.PhotoImage(file="logo.png") # makes a variable containing the logo image file
    spadeLogo = tkinter.Label(spadeApp, image=logo, border=0, bg="green") # creates a packable object 
    spadeLogo.pack(ipady=20, fill=tkinter.X) # Inserts the logo at the top of the window
    

    global googleMap
    googleMap = tkinter.PhotoImage(file="Maps/Distance.png") # unused file, we were planning to use an interactive google map, but settled on a png for the sake of time.
    tkinter.Label(spadeApp, image=googleMap, border=5, bg="black").pack()
        

    def clickOnStaff(): # shows more info about the clicked staff, and gives the option to hire the staff - made by matteo and ryan
        def saveUserChoice(): # save the hired staff in a file, so they can be reviewed the next time the app is opened - made by matteo and ryan
            with open("staff.txt", "w") as staffFile:
                staffFile.write(f"{staffChoice[0]} {staffChoice[1]}.") # save the hired staff
                messagebox.showinfo("Hired!", "Your order is complete! Our staff is on their way!") # tell the user they have successfully hired the person
                messagebox.showinfo("Hired!", "You may close this window now.")

        try:
            staffInputNumber = int(staffInput.get()) # take the inputted choice of staff from the user
            if int(staffInputNumber) > 5 or int(staffInputNumber) <= 0: # if the input is invalid 
                messagebox.showinfo("Not In List", "Please select a staff listed below.") # notify user the input is invalid
            else:# if the input is valid
                staffChoice = staffDictionary[staffInputNumber] # Set a variable to the users choice of staff

                # Open a window with more info about the chosen staff
                moreInfo = tkinter.Tk() 
                appWidth = 540 # Set the window width
                appHeight = 540 # Set the window height
                compWidth = moreInfo.winfo_screenwidth()  # Width of the screen
                compHeight = moreInfo.winfo_screenheight() # Height of the screen
                x = (compWidth/2) - (appWidth/2) # Spawn the window in the middle of the screen
                y = (compHeight/2) - (appHeight/2)
                moreInfo.geometry('%dx%d+%d+%d' % (appWidth, appHeight, x, y))# determines the size of the window
                moreInfo.iconbitmap('icon.ico')
                moreInfo.title('More Info')
                moreInfo.configure(bg='green')
                moreInfo.resizable(False,False) #Makes the window unable to be resized   
                
                infoFrame = tkinter.Frame(moreInfo, width=540, bg="green")  # a container that will hold the staffs printed info
                infoFrame.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.CENTER)
                
                #indexs tuple and prints name and pay
                tkinter.Label(infoFrame, text=(f"{staffChoice[0]} {staffChoice[1]}."), font=("Microsoft Yahei Bold", 30), fg="white", bg="green").pack(side=tkinter.LEFT, ipadx=40)
                tkinter.Label(infoFrame, text=(f"{staffChoice[2]}"), font=("Microsoft Yahei Bold", 30), fg="white", bg="green").pack(side=tkinter.RIGHT, ipadx=40)
                
                infoFrame2 = tkinter.Frame(moreInfo, width=540, bg="green")  # a container
                infoFrame2.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.CENTER)

                #indexs tuple and prints name and pay
                tkinter.Label(infoFrame2, text=(f"{staffChoice[3]}"), font=("Microsoft Yahei Bold", 22), fg="white", bg="green").pack(side=tkinter.LEFT, ipadx=40)
                tkinter.Label(infoFrame2, text=(f"{staffChoice[4]}⭐"), font=("Microsoft Yahei Bold", 22), fg="white", bg="green").pack(side=tkinter.RIGHT, ipadx=40)
                
                gmaps = googlemaps.Client(key = "PLACE KEY HERE :pppp") 
                with open("location.txt", "r") as userTown1:
                    #variable just to get to the next line
                    region1 = userTown1.readline() 
                    #grab user town from txt file
                    town1 = (f"{userTown1.readline()}, Canada") 
                town2 = (f"{staffChoice[3]}, Canada")
                staffTime = gmaps.distance_matrix(town1, town2) #finds the distance, and calculates how far and long it will take by car

                infoFrame3 = tkinter.Frame(moreInfo, width=540, bg="green")  # a container
                infoFrame3.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.CENTER)
                
                #using google maps calculate the distace and time by car then print it
                tkinter.Label(infoFrame3, text=(f"{staffChoice[0]} is {staffTime['rows'][0]['elements'][0]['distance']['text']} away from you"), font=("Microsoft Yahei Bold", 20), fg="white", bg="green").pack(ipadx=40)
                tkinter.Label(infoFrame3, text=(f"{staffChoice[0]} can be there in {staffTime['rows'][0]['elements'][0]['duration']['text']}"), font=("Microsoft Yahei Bold", 20), fg="white", bg="green").pack(ipadx=40)
                
                descriptionFrame = tkinter.Frame(moreInfo, width=540, bg="green")  # a container
                descriptionFrame.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.CENTER)
                tkinter.Label(descriptionFrame, text=(f"{staffChoice[5]}"), font=("Microsoft Yahei Bold", 16), fg="white", bg="green").pack(ipadx=40)
                
                #Button gives the option to hire the staff
                buttonFrame = tkinter.Frame(moreInfo, width=540, bg="green")  # a container
                buttonFrame.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.CENTER)
                tkinter.Button(buttonFrame, text = f'Would you like to hire {staffChoice[0]}?',border = 1,font =("Microsoft Yahei Light", 18), command=saveUserChoice, cursor="hand2").pack()

                
        except:
            messagebox.showinfo("Not a Number", "Please input a staff number.")# if the user does not enter a number print message box
        
    staffDictionary = {}
    for number in range(5): # runs 5 times, each time creating a staff member
        staffName, staffLastInitial, staffPay, staffLocation, staffStars, staffDescriptions = createDude(nameList, LastInitialList, jobDict, staffLocList)
        staffDictionary[number+1] = (staffName, staffLastInitial, staffPay, staffLocation, staffStars, staffDescriptions)
        
        staffFrame = tkinter.Frame(spadeApp, width=540, bg="white")  # its a container that will hold the staffs printed info
        staffFrame.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
        
        #print staff name on left and pay on right
        tkinter.Label(staffFrame, text=(f"{number+1}.  {staffName} {staffLastInitial}."), font=("Microsoft Yahei Bold", 16), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
        tkinter.Label(staffFrame, text=(f"{staffPay}"), font=("Microsoft Yahei Bold", 16), fg="black", bg="white").pack(side=tkinter.RIGHT, ipadx=30)
        
        staffFrame2 = tkinter.Frame(spadeApp, width=540, bg="white")  # its a container
        staffFrame2.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N)
        
        #print staff location on left and stars on right
        tkinter.Label(staffFrame2, text=(f"{staffLocation}"), font=("Microsoft Yahei Bold", 12), fg="black", bg="white").pack(side=tkinter.LEFT, ipadx=30)
        tkinter.Label(staffFrame2, text=(f"{staffStars}⭐"), font=("Microsoft Yahei Bold", 12), fg="black", bg="white").pack(side=tkinter.RIGHT, ipadx=30)
        
        #spacer
        tkinter.Frame(spadeApp, width=540, bg="white").pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.N, ipady=7)

    # input for choosing staff
    staffInputFrame = tkinter.Frame(spadeApp, width=540, bg="white")  # its a container that will hold the staffs printed info
    staffInputFrame.pack(side=tkinter.TOP, fill=tkinter.X, expand=1, anchor=tkinter.S, ipady=4)

    staffInput = tkinter.Entry(staffInputFrame, width=22, fg="black", border=2, bg="white", font=("Microsoft Yahei", 14))#textbox to recive input
    staffInput.pack(side=tkinter.LEFT, ipadx=30)
    staffInput.insert(0, "(Ex. 1)")    
    
    tkinter.Button(staffInputFrame, text="Enter Staff Number", border=1, font=("Microsoft Yahei Light", 14), command=clickOnStaff, cursor="hand2").pack(side=tkinter.RIGHT, ipadx=30)#runs function when clicked
    tkinter.Frame(spadeApp, width=540, bg="white").pack(side=tkinter.BOTTOM, fill=tkinter.X, expand=1, anchor=tkinter.S, ipady=4)#spacer

    spadeApp.protocol("WM_DELETE_WINDOW", review)
    
def loginCreation():
    with open("login.txt", "r+") as txtFile: #open the login text file
        
        windowWidth = 364
        windowHeight = 338
        if txtFile.read() == "": # If the file is empty, then create username and password
            #transistion from splash to sign in
            def logupTxt(): # creates a login for the user: made by matteo
                with open("login.txt", "r+") as txtFileup:
                    usernameupTxt=usernameup.get()
                    passwordupTxt=passwordup.get()
                    txtFileup.write(f"{usernameupTxt}\n{passwordupTxt}")
                    messagebox.showinfo("Sign Up", "Sign up sucessful, please restart app")
                    signUp.quit()

            #stop splash and start sign in
            splashScreen.destroy()
            #this part of the code handles sign ins
            global signUp
            signUp = tkinter.Tk()
            screenWidth = signUp.winfo_screenwidth()  # Width of the screen
            screenHeight = signUp.winfo_screenheight() # Height of the screen
            x = (screenWidth/2) - (windowWidth/2)
            y = (screenHeight/2) - (windowHeight/2)
            signUp.geometry('%dx%d+%d+%d' % (windowWidth, windowHeight, x, y))

            signUp.iconbitmap("icon.ico") # Icon for window
            signUp.title("SIGN UP") # Title of the window
            signUp.configure(bg="green") # Sets background colour of the window
            signUp.resizable(False,False) # The user cannot resize the window

            logo = tkinter.PhotoImage(file="logo.png") # puts in the logo
            tkinter.Label(signUp, image=logo, border=0, bg="green").place(x = 182, y=50, anchor="center")
            
            # Sign up window
            inputFrame = tkinter.Frame(signUp, width=182, height=300, bg="green")
            inputFrame.place(x = windowWidth/2-28, y = windowHeight/2+90, anchor="center")
            tkinter.Label(signUp, text="Welcome", font=("Microsoft Yahei", 18), fg="white", bg="green").place(x = 129, y=84)
            tkinter.Label(signUp, text="Create a username and password below", font=("Microsoft Yahei Light", 12), fg="white", bg="green").place(x = 33, y=119)
            #------USERNAME-------
            usernameup = tkinter.Entry(inputFrame, width=25, fg="black", border=2, bg="white", font=("Microsoft Yahei", 10), cursor="hand2")
            usernameup.place(x=56, y=50)
            usernameup.insert(0, "Username") #puts text in box before user
            #------PASSWORD-------
            passwordup = tkinter.Entry(inputFrame, width=25, fg="black", border=2, bg="white", font=("Microsoft Yahei", 10), cursor="hand2")
            passwordup.place(x=56, y=100)
            passwordup.insert(0, "Password")
            #------BUTTON-------
            tkinter.Button(inputFrame, width=12, text="Sign Up", border=0, font=("Microsoft Yahei Light", 10), command=logupTxt, cursor="hand2").place(x=68, y=150)

        else:
            def loginTxt(): # goes through login process - made by matteo and ryan
                usernameTxt=username.get()
                passwordTxt=password.get()
                with open("login.txt", "r+") as txtFile:
                    loginInfo = txtFile.read().splitlines()
                    if usernameTxt == loginInfo[0] and passwordTxt == loginInfo[1]:
                            messagebox.showinfo("Sign In", "Signed in! Press OK to continue")
                            signIn.after(200, locationAsk)
                    else:
                        messagebox.showinfo("Wrong Login", "Incorrect login info, Try again")  

            #stop splash and start sign in
            splashScreen.destroy()
            #this part of the code handles sign in
            global signIn
            signIn = tkinter.Tk()
            screenWidth = signIn.winfo_screenwidth()  # Width of the screen
            screenHeight = signIn.winfo_screenheight() # Height of the screen
            x = (screenWidth/2) - (windowWidth/2)
            y = (screenHeight/2) - (windowHeight/2)
            signIn.geometry('%dx%d+%d+%d' % (windowWidth, windowHeight, x, y))

            #icon and title of window
            signIn.iconbitmap("icon.ico")
            signIn.title("SIGN IN")
            signIn.configure(bg="green")
            signIn.resizable(False,False)

            #logo of window
            logo = tkinter.PhotoImage(file="logo.png")
            tkinter.Label(signIn, image=logo, border=0, bg="green").place(x = 182, y=50, anchor="center")

            #container that holds the username and password entry
            inputFrame = tkinter.Frame(signIn, width=182, height=300, bg="green")
            inputFrame.place(x = windowWidth/2-28, y = windowHeight/2+70, anchor="center")
            tkinter.Label(signIn, text="Sign In", font=("Microsoft Yahei", 18), fg="white", bg="green").place(x = 140, y = 81)
            #------USERNAME-------
            username = tkinter.Entry(inputFrame, width=25, fg="black", border=2, bg="white", font=("Microsoft Yahei", 10), cursor="hand2")
            username.place(x=56, y=50)
            username.insert(0, "Username") #puts text in box before user
            #------PASSWORD-------
            password = tkinter.Entry(inputFrame, width=25, fg="black", border=2, bg="white", font=("Microsoft Yahei", 10), cursor="hand2")
            password.place(x=56, y=100)
            password.insert(0, "Password")
            #------BUTTON-------
            tkinter.Button(inputFrame, width=12, text="Sign In", border=0, font=("Microsoft Yahei Light", 10), command=loginTxt, cursor="hand2").place(x=68, y=150)
splashScreen.after(2000,loginCreation)

tkinter.mainloop()#runs everything in a while loop     